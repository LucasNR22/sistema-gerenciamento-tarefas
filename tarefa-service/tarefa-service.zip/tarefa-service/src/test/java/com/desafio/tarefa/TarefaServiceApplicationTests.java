package com.desafio.tarefa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TarefaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
