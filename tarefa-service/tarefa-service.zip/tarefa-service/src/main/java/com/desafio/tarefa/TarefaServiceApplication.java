package com.desafio.tarefa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TarefaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TarefaServiceApplication.class, args);
	}

}
